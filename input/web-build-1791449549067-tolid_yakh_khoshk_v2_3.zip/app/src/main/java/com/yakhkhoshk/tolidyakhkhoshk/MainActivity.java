package com.yakhkhoshk.tolidyakhkhoshk;

import android.app.*;
import android.os.Bundle;
import android.content.*;
import android.graphics.Typeface;
import android.net.Uri;
import android.provider.Settings;
import android.view.*;
import android.widget.*;
import org.json.*;
import java.io.*;
import java.text.DecimalFormat;
import java.util.*;

public class MainActivity extends Activity {
    private static final int CREATE_BACKUP = 1001, OPEN_BACKUP = 1002;
    private final ArrayList<Customer> customers = new ArrayList<>();
    private final DecimalFormat moneyFmt = new DecimalFormat("#,###.##");
    private LinearLayout root, content;
    private TextView title;
    private int textSize = 18;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(android.graphics.Color.rgb(17,24,39));
        getWindow().setNavigationBarColor(android.graphics.Color.rgb(17,24,39));
        loadData(); buildShell(); showCustomers();
    }

    private void buildShell() {
        root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        root.setBackgroundColor(0xFFF7F7F8);
        LinearLayout bar = new LinearLayout(this); bar.setGravity(Gravity.CENTER_VERTICAL); bar.setPadding(18,16,18,16); bar.setBackgroundColor(0xFF111827);
        title = tv("تولید یخ خشک",20,true); title.setTextColor(0xFFFFFFFF); bar.addView(title,new LinearLayout.LayoutParams(0,70,1));
        TextView menu = tv("☰",30,true); menu.setTextColor(0xFFFFFFFF); menu.setGravity(Gravity.CENTER); bar.addView(menu,new LinearLayout.LayoutParams(60,70)); menu.setOnClickListener(v->showMenu());
        root.addView(bar);
        content = new LinearLayout(this); content.setOrientation(LinearLayout.VERTICAL); content.setPadding(14,14,14,14); root.addView(content,new LinearLayout.LayoutParams(-1,0,1));
        LinearLayout nav = new LinearLayout(this); nav.setPadding(6,6,6,8); nav.setGravity(Gravity.CENTER); nav.setBackgroundColor(0xFFFFFFFF);
        addNav(nav,"مشتریان",v->showCustomers()); addNav(nav,"گزارش",v->showReport()); addNav(nav,"ماشین حساب",v->showCalculator()); addNav(nav,"پشتیبان",v->showBackup());
        root.addView(nav,new LinearLayout.LayoutParams(-1,ViewGroup.LayoutParams.WRAP_CONTENT)); setContentView(root);
    }
    private void addNav(LinearLayout nav,String s,View.OnClickListener l){ Button b=btn(s); b.setTextSize(15); nav.addView(b,new LinearLayout.LayoutParams(0,58,1)); b.setOnClickListener(l); }
    private TextView tv(String s,float size,boolean bold){ TextView t=new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(0xFF111827); t.setGravity(Gravity.CENTER_VERTICAL); if(bold)t.setTypeface(Typeface.DEFAULT,Typeface.BOLD); t.setPadding(8,4,8,4); t.setLayoutDirection(View.LAYOUT_DIRECTION_RTL); return t; }
    private Button btn(String s){ Button b=new Button(this); b.setText(s); b.setTextSize(textSize); b.setAllCaps(false); b.setMinHeight(52); b.setPadding(10,2,10,2); return b; }
    private EditText edit(String hint){ EditText e=new EditText(this); e.setHint(hint); e.setTextSize(textSize); e.setPadding(12,8,12,8); e.setGravity(Gravity.RIGHT|Gravity.CENTER_VERTICAL); e.setLayoutDirection(View.LAYOUT_DIRECTION_RTL); return e; }
    private void clear(){content.removeAllViews();}
    private ScrollView scroll(LinearLayout box){ ScrollView s=new ScrollView(this); s.setLayoutDirection(View.LAYOUT_DIRECTION_RTL); s.addView(box); return s; }

    private void showCustomers(){ clear(); title.setText("مشتریان");
        LinearLayout box=new LinearLayout(this); box.setOrientation(LinearLayout.VERTICAL);
        Button add=btn("＋ افزودن مشتری"); box.addView(add,new LinearLayout.LayoutParams(-1,60)); add.setOnClickListener(v->customerDialog(null));
        EditText search=edit("جستجوی نام یا تلفن"); box.addView(search,new LinearLayout.LayoutParams(-1,60));
        LinearLayout list=new LinearLayout(this); list.setOrientation(LinearLayout.VERTICAL); box.addView(list,new LinearLayout.LayoutParams(-1,ViewGroup.LayoutParams.WRAP_CONTENT));
        Runnable refresh=()->{list.removeAllViews(); String q=search.getText().toString().trim(); for(Customer c:customers){if(q.length()>0&&!((c.name+" "+c.phone).contains(q)))continue; addCustomerRow(list,c);} if(customers.size()==0) list.addView(tv("هنوز مشتری ثبت نشده است.",18,false));};
        search.addTextChangedListener(new android.text.TextWatcher(){public void beforeTextChanged(CharSequence s,int st,int c,int a){} public void onTextChanged(CharSequence s,int st,int b,int c){refresh.run();} public void afterTextChanged(android.text.Editable e){}}); refresh.run(); content.addView(scroll(box),new LinearLayout.LayoutParams(-1,0,1));
    }
    private void addCustomerRow(LinearLayout list,Customer c){
        LinearLayout row=new LinearLayout(this); row.setOrientation(LinearLayout.VERTICAL); row.setPadding(12,8,12,8); row.setBackgroundColor(0xFFFFFFFF);
        TextView n=tv(c.name,20,true); row.addView(n); double bal=c.balance(); TextView b=tv("مانده: "+money(bal)+"  تومان"+(bal>0?" (بدهکار)":bal<0?" (بستانکار)":""),17,false); b.setTextColor(bal==0?0xFF374151:bal>0?0xFFB91C1C:0xFF047857); row.addView(b);
        TextView p=tv(c.phone.length()>0?"تلفن: "+c.phone:"بدون تلفن",16,false); row.addView(p);
        LinearLayout actions=new LinearLayout(this); Button open=btn("حساب مشتری"), edit=btn("ویرایش"), del=btn("حذف"); actions.addView(open,new LinearLayout.LayoutParams(0,52,1)); actions.addView(edit,new LinearLayout.LayoutParams(0,52,1)); actions.addView(del,new LinearLayout.LayoutParams(0,52,1)); row.addView(actions); list.addView(row,new LinearLayout.LayoutParams(-1,ViewGroup.LayoutParams.WRAP_CONTENT));
        View.OnClickListener dial=v->{if(c.phone.length()>0)startActivity(new Intent(Intent.ACTION_DIAL,Uri.parse("tel:"+c.phone)));else toast("شماره تلفن ثبت نشده است.");}; p.setOnClickListener(dial);
        open.setOnClickListener(v->customerAccount(c)); edit.setOnClickListener(v->customerDialog(c)); del.setOnClickListener(v->confirmDeleteCustomer(c));
        Space sp=new Space(this); list.addView(sp,new LinearLayout.LayoutParams(1,8));
    }
    private void customerDialog(Customer c){
        LinearLayout box=new LinearLayout(this); box.setOrientation(LinearLayout.VERTICAL); EditText name=edit("نام / شرکت *"), phone=edit("شماره تلفن"); name.setSingleLine(); phone.setSingleLine(); if(c!=null){name.setText(c.name);phone.setText(c.phone);} box.addView(name);box.addView(phone);
        AlertDialog d=new AlertDialog.Builder(this).setTitle(c==null?"مشتری جدید":"ویرایش مشتری").setView(box).setNegativeButton("انصراف",null).setPositiveButton("ذخیره",null).create(); d.setOnShowListener(x->d.getButton(-1).setOnClickListener(v->{String n=name.getText().toString().trim();if(n.length()==0){name.setError("نام را وارد کنید");return;}if(c==null)customers.add(new Customer(n,phone.getText().toString().trim()));else{c.name=n;c.phone=phone.getText().toString().trim();}saveData();d.dismiss();showCustomers();})); d.show();
    }
    private void confirmDeleteCustomer(Customer c){ new AlertDialog.Builder(this).setTitle("حذف مشتری").setMessage("مشتری و تمام تراکنش‌های او حذف شود؟").setNegativeButton("انصراف",null).setPositiveButton("حذف",(d,w)->{customers.remove(c);saveData();showCustomers();}).show(); }

    private void customerAccount(Customer c){ clear(); title.setText(c.name); LinearLayout box=new LinearLayout(this);box.setOrientation(LinearLayout.VERTICAL);
        TextView balance=tv("مانده: "+money(c.balance())+" تومان",22,true); balance.setGravity(Gravity.CENTER); box.addView(balance,new LinearLayout.LayoutParams(-1,70));
        if(c.phone.length()>0){Button dial=btn("☎ تماس با "+c.phone);box.addView(dial);dial.setOnClickListener(v->startActivity(new Intent(Intent.ACTION_DIAL,Uri.parse("tel:"+c.phone))));}
        LinearLayout acts=new LinearLayout(this); Button receive=btn("＋ دریافت"), pay=btn("− پرداخت"); acts.addView(receive,new LinearLayout.LayoutParams(0,60,1));acts.addView(pay,new LinearLayout.LayoutParams(0,60,1));box.addView(acts);receive.setOnClickListener(v->transactionDialog(c,true,null));pay.setOnClickListener(v->transactionDialog(c,false,null));
        box.addView(tv("سابقه تراکنش‌ها",20,true)); LinearLayout list=new LinearLayout(this);list.setOrientation(LinearLayout.VERTICAL); if(c.txns.size()==0)list.addView(tv("تراکنشی ثبت نشده است.",18,false)); else {for(Transaction t:c.txns)addTxnRow(list,c,t);} box.addView(list); Button back=btn("← بازگشت به مشتریان");back.setOnClickListener(v->showCustomers());box.addView(back);content.addView(scroll(box),new LinearLayout.LayoutParams(-1,0,1));
    }
    private void addTxnRow(LinearLayout list,Customer c,Transaction t){ LinearLayout row=new LinearLayout(this);row.setOrientation(LinearLayout.VERTICAL);row.setPadding(12,7,12,7);row.setBackgroundColor(0xFFFFFFFF);String type=t.receive?"دریافت":"پرداخت"; TextView a=tv(type+"  |  "+money(t.amount)+" تومان",18,true);a.setTextColor(t.receive?0xFF047857:0xFFB91C1C);row.addView(a);row.addView(tv("تاریخ: "+t.date+"   |   "+(t.desc.length()>0?t.desc:"بدون شرح"),16,false));LinearLayout ac=new LinearLayout(this);Button e=btn("ویرایش"),d=btn("حذف");ac.addView(e,new LinearLayout.LayoutParams(0,50,1));ac.addView(d,new LinearLayout.LayoutParams(0,50,1));row.addView(ac);e.setOnClickListener(v->transactionDialog(c,t.receive,t));d.setOnClickListener(v->new AlertDialog.Builder(this).setTitle("حذف تراکنش").setMessage("این تراکنش حذف شود؟").setNegativeButton("انصراف",null).setPositiveButton("حذف",(x,w)->{c.txns.remove(t);saveData();customerAccount(c);}).show());list.addView(row);Space sp=new Space(this);list.addView(sp,new LinearLayout.LayoutParams(1,8)); }

    private void transactionDialog(Customer c,boolean receive,Transaction old){ LinearLayout box=new LinearLayout(this);box.setOrientation(LinearLayout.VERTICAL);EditText amount=edit("مبلغ به تومان *"),date=edit("تاریخ شمسی (مثلاً 1405/07/16)"),desc=edit("شرح");amount.setInputType(2|8192);date.setSingleLine();desc.setSingleLine();amount.setSingleLine();date.setText(old==null?PersianDate.today():old.date);if(old!=null){amount.setText(String.valueOf(old.amount));desc.setText(old.desc);}box.addView(amount);box.addView(date);box.addView(desc);String ttl=(old==null?"ثبت ":"ویرایش ")+(receive?"دریافت":"پرداخت");AlertDialog d=new AlertDialog.Builder(this).setTitle(ttl).setView(box).setNegativeButton("انصراف",null).setPositiveButton("ذخیره",null).create();d.setOnShowListener(x->d.getButton(-1).setOnClickListener(v->{try{double a=Double.parseDouble(amount.getText().toString().replace(",",""));if(a<=0)throw new Exception();String dt=date.getText().toString().trim();if(dt.length()==0)throw new Exception();if(old==null)c.txns.add(new Transaction(receive,a,dt,desc.getText().toString().trim()));else{old.amount=a;old.date=dt;old.desc=desc.getText().toString().trim();}saveData();d.dismiss();customerAccount(c);}catch(Exception ex){amount.setError("مبلغ معتبر وارد کنید");}}));d.show(); }

    private void showReport(){clear();title.setText("گزارش");LinearLayout box=new LinearLayout(this);box.setOrientation(LinearLayout.VERTICAL);double rec=0,pay=0;for(Customer c:customers)for(Transaction t:c.txns){if(t.receive)rec+=t.amount;else pay+=t.amount;}box.addView(tv("تعداد مشتریان: "+customers.size(),20,true));box.addView(tv("مجموع دریافت‌ها: "+money(rec)+" تومان",19,false));box.addView(tv("مجموع پرداخت‌ها: "+money(pay)+" تومان",19,false));box.addView(tv("خالص: "+money(rec-pay)+" تومان",21,true));for(Customer c:customers){box.addView(tv("• "+c.name+": "+money(c.balance())+" تومان",18,false));}content.addView(scroll(box),new LinearLayout.LayoutParams(-1,0,1));}

    private void showCalculator(){clear();title.setText("ماشین حساب");LinearLayout box=new LinearLayout(this);box.setOrientation(LinearLayout.VERTICAL);EditText expr=edit("مثلاً 120000 × 3");expr.setTextSize(22);box.addView(expr);TextView result=tv("نتیجه: ",24,true);result.setGravity(Gravity.CENTER);box.addView(result,new LinearLayout.LayoutParams(-1,70));String[][] keys={{"7","8","9","÷"},{"4","5","6","×"},{"1","2","3","−"},{"0",".","C","+"},{"="}};for(String[] line:keys){LinearLayout r=new LinearLayout(this);for(String k:line){Button b=btn(k);r.addView(b,new LinearLayout.LayoutParams(0,62,k.equals("=")?4:1));b.setOnClickListener(v->{String s=((Button)v).getText().toString();if(s.equals("C"))expr.setText("");else if(s.equals("=")){try{result.setText("نتیجه: "+Calculator.eval(expr.getText().toString()));}catch(Exception e){result.setText("خطا در عبارت");}}else expr.append(s);});}box.addView(r);}content.addView(scroll(box),new LinearLayout.LayoutParams(-1,0,1));}

    private void showBackup(){clear();title.setText("پشتیبان");LinearLayout box=new LinearLayout(this);box.setOrientation(LinearLayout.VERTICAL);box.addView(tv("برای جلوگیری از از دست رفتن اطلاعات، هر چند وقت یک‌بار پشتیبان بگیرید.",18,false));Button backup=btn("⬇ تهیه فایل پشتیبان"),restore=btn("⬆ بازیابی پشتیبان");box.addView(backup);box.addView(restore);backup.setOnClickListener(v->{Intent i=new Intent(Intent.ACTION_CREATE_DOCUMENT);i.setType("application/json");i.putExtra(Intent.EXTRA_TITLE,"tolid_yakh_khoshk_backup.json");startActivityForResult(i,CREATE_BACKUP);});restore.setOnClickListener(v->{Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.setType("application/json");i.addCategory(Intent.CATEGORY_OPENABLE);startActivityForResult(i,OPEN_BACKUP);});content.addView(scroll(box),new LinearLayout.LayoutParams(-1,0,1));}
    @Override protected void onActivityResult(int req,int res,Intent data){super.onActivityResult(req,res,data);if(res!=RESULT_OK||data==null)return;try{if(req==CREATE_BACKUP){String json=toJson().toString(2);OutputStream out=getContentResolver().openOutputStream(data.getData());out.write(json.getBytes("UTF-8"));out.close();toast("پشتیبان با موفقیت ذخیره شد.");}else if(req==OPEN_BACKUP){InputStream in=getContentResolver().openInputStream(data.getData());ByteArrayOutputStream buf=new ByteArrayOutputStream();byte[] b=new byte[4096];int n;while((n=in.read(b))!=-1)buf.write(b,0,n);in.close();fromJson(new String(buf.toByteArray(),"UTF-8"));saveData();showCustomers();toast("اطلاعات بازیابی شد.");}}catch(Exception e){toast("خطا در پشتیبان: "+e.getMessage());}}

    private JSONObject toJson()throws Exception{JSONObject o=new JSONObject();JSONArray arr=new JSONArray();for(Customer c:customers){JSONObject cj=new JSONObject();cj.put("name",c.name);cj.put("phone",c.phone);JSONArray ts=new JSONArray();for(Transaction t:c.txns){JSONObject tj=new JSONObject();tj.put("receive",t.receive);tj.put("amount",t.amount);tj.put("date",t.date);tj.put("desc",t.desc);ts.put(tj);}cj.put("transactions",ts);arr.put(cj);}o.put("customers",arr);o.put("version",22);return o;}
    private void fromJson(String s)throws Exception{JSONObject o=new JSONObject(s);JSONArray arr=o.getJSONArray("customers");customers.clear();for(int i=0;i<arr.length();i++){JSONObject cj=arr.getJSONObject(i);Customer c=new Customer(cj.optString("name"),cj.optString("phone"));JSONArray ts=cj.optJSONArray("transactions");if(ts!=null)for(int j=0;j<ts.length();j++){JSONObject t=ts.getJSONObject(j);c.txns.add(new Transaction(t.optBoolean("receive"),t.optDouble("amount"),t.optString("date"),t.optString("desc")));}customers.add(c);}}
    private void loadData(){try{String s=getPreferences(0).getString("data","");if(s.length()>0)fromJson(s);}catch(Exception ignored){}}
    private void saveData(){try{getPreferences(0).edit().putString("data",toJson().toString()).apply();}catch(Exception ignored){}}
    private String money(double x){return moneyFmt.format(x);}
    private void toast(String s){Toast.makeText(this,s,Toast.LENGTH_LONG).show();}
    private void showMenu(){new AlertDialog.Builder(this).setItems(new String[]{"مشتریان","گزارش","ماشین حساب","پشتیبان","اطلاعات برنامه"},(d,w)->{if(w==0)showCustomers();else if(w==1)showReport();else if(w==2)showCalculator();else if(w==3)showBackup();else new AlertDialog.Builder(this).setTitle("تولید یخ خشک").setMessage("نسخه 2.2\nدفتر ساده مشتریان و دریافت/پرداخت").setPositiveButton("باشه",null).show();}).show();}

    static class Customer{String name,phone;ArrayList<Transaction> txns=new ArrayList<>();Customer(String n,String p){name=n;phone=p;}double balance(){double x=0;for(Transaction t:txns)x+=t.receive?t.amount:-t.amount;return x;}}
    static class Transaction{boolean receive;double amount;String date,desc;Transaction(boolean r,double a,String d,String x){receive=r;amount=a;date=d;desc=x;}}
    static class PersianDate{static String today(){Calendar c=Calendar.getInstance();return toJ(c.get(Calendar.YEAR),c.get(Calendar.MONTH)+1,c.get(Calendar.DAY_OF_MONTH));}static String toJ(int gy,int gm,int gd){int[] gdm={31,28,31,30,31,30,31,31,30,31,30,31};int gy2=gy-1600,gm2=gm-1,gd2=gd-1;int gDay=365*gy2+(gy2+3)/4-(gy2+99)/100+(gy2+399)/400;for(int i=0;i<gm2;i++)gDay+=gdm[i];if(gm2>1&&((gy%4==0&&gy%100!=0)||gy%400==0))gDay++;gDay+=gd2;int jDay=gDay-79;int jNp=jDay/12053;jDay%=12053;int jy=979+33*jNp+4*(jDay/1461);jDay%=1461;if(jDay>=366){jy+=(jDay-1)/365;jDay=(jDay-1)%365;}int jm=jDay<186?1+jDay/31:7+(jDay-186)/30;int jd=1+(jDay<186?jDay%31:(jDay-186)%30);return String.format(Locale.US,"%04d/%02d/%02d",jy,jm,jd);}}
    static class Calculator{static double eval(String s)throws Exception{String x=s.replace("×","*").replace("÷","/").replace("−","-").replace(",","").replace(" ","");if(x.length()==0)throw new Exception();ArrayList<Double> nums=new ArrayList<>();ArrayList<Character> ops=new ArrayList<>();StringBuilder n=new StringBuilder();for(int i=0;i<x.length();i++){char c=x.charAt(i);if((c>='0'&&c<='9')||c=='.'||(c=='-'&&(i==0||x.charAt(i-1)=='*'||x.charAt(i-1)=='/'))){n.append(c);}else if(c=='+'||c=='-'||c=='*'||c=='/'){if(n.length()==0)throw new Exception();nums.add(Double.parseDouble(n.toString()));n.setLength(0);ops.add(c);}else throw new Exception();}if(n.length()==0)throw new Exception();nums.add(Double.parseDouble(n.toString()));for(int i=0;i<ops.size();){char op=ops.get(i);if(op=='*'||op=='/'){double a=nums.get(i),b=nums.get(i+1);if(op=='/'&&b==0)throw new Exception();nums.set(i,op=='*'?a*b:a/b);nums.remove(i+1);ops.remove(i);}else i++;}double r=nums.get(0);for(int i=0;i<ops.size();i++)r=ops.get(i)=='+'?r+nums.get(i+1):r-nums.get(i+1);return r;}}
}
